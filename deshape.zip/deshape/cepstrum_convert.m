function [ceps0, tceps, ceptic] = cepstrum_convert(tfr, tfrtic,...
    g, fs, Tc, num_s, HighFreq, LowFreq)

% upsample the cepstrum to get accurate inverse cepstrum
UpSample = 20 ;



if g~=0
    ceps = real(ifft(abs(tfr).^g, 2*size(tfr,1), 1));
else
    ceps = real(ifft(log(abs(tfr)), 2*size(tfr,1), 1));
end

CepstrumRange = 1./((tfrtic(2)-tfrtic(1)) * fs) ;
ceptic = CepstrumRange * (1: size(tfr,1)) / (2*size(tfr,1)) ;


for mi=1:size(ceps,2)
    tra = min(find(ceps(3:round(1/LowFreq),mi)<0))-1+3;
    if tra>=1
        ceps(1:max([round(1/HighFreq) tra]),mi)=0;
    else
    end
end

ceps(1:round(1/HighFreq),:)=0; 



ceps = ceps(1:round(1/LowFreq),:) ;
ceptic = ceptic(1:round(1/LowFreq)) ;
ceps0 = ceps;
ceps =  interp1(1:size(ceps,1), ceps, 1:1/UpSample:size(ceps,1));
tceps = zeros(length(tfrtic), size(ceps,2));
	% cepstrum quefrency scale
freq_scale = UpSample.*fs./(1:size(ceps,1)-1);
empt = [];


for ii = 2:length(tfrtic)-1
		% index in quefency
    p_index = find(freq_scale > (tfrtic(ii-1)+tfrtic(ii))*fs/2 & freq_scale <= (tfrtic(ii+1)+tfrtic(ii))*fs/2);
    if isempty(p_index)
        empt = [empt; ii];
    else
        %tceps(ii,:)=sum(ceps(p_index,:),1);
		weight = abs(1./p_index) ;
        tceps(ii,:)=sum(diag(weight)*ceps(p_index,:),1);
    end
end
tceps(tceps<Tc)=0;
tceps_new = tceps;

	% how many peaks in cepstrum (num_s)
if num_s>1
    for fi = round(LowFreq*fs*num_s)+1:size(tceps,1)
        for kk = 2:num_s
            tceps_new(fi,:)=tceps(fi,:).*tceps(max([1 round(fi/kk)]),:);
        end
    end

end
tceps = tceps_new;

