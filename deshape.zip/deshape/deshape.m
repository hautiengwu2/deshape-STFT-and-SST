function [tfr, ceps, ceptic, iceps, dstfr, dstfrsq, tfrsq, tfrtic] =...
    deshape(x, basicTF, advTF, cepR, P)

% basic parameters for STFT
win = basicTF.win;
hop = basicTF.hop;
feat = basicTF.feat;
fs = basicTF.fs;
fr = basicTF.fr;

% advanced parameters for STFT
HighFreq = advTF.HighFreq;
LowFreq = advTF.LowFreq;
num_tap = advTF.num_tap;
win_type = advTF.win_type;
Smo = advTF.Smo;
Rej = advTF.Rej;
ths = advTF.ths;
lpc = advTF.lpc;

num_s = P.num_s;
num_c = P.num_c;

% get window
h = tftb_window(win, win_type);
Dh = dwindow(h);
Dho = dwindow(Dh);

h = [h Dh];
Dh = [Dh Dho];

% parameters for cepstral representation
g = cepR.g;
Tc = cepR.Tc;


% when you need conceFT
MT = num_tap;
for ii = 1:MT

    if MT>1
        fprintf(['ConceFT total: ',num2str(MT),'; now: %4d\n'], ii) ;
    end


    if MT == 1
        rv = [1 0];
    else
        rv = randn(1, 2) ;  %rv(2)=0;
        rv = rv ./ norm(rv) ;
    end
    rh = rv * h';
    rDh = rv * Dh';
    h2 = rh'; Dh2 = rDh';



    % run STFT
    [tfr, ifd, tfrtic, Stime] = STFT_IFD_fast(x, fr/fs, hop, h2, Dh2);
    tfr = abs(tfr);



    % get cepstrum
    if g~=0
        ceps0 = 2.*real(ifft(abs(tfr).^g, 2*size(tfr,1), 1));
    else
        ceps0 = 2.*real(ifft(log(abs(tfr)), 2*size(tfr,1), 1));
    end

    bnd = floor(1/HighFreq);
    ceps0(bnd+1:end-bnd,:) = 0;
    flo = (real(fft(ceps0))).^(1/g); 
    flo = flo(1:size(tfr,1),:);
    clear ceps0
        

    % get inverse cepstrum (a bit redundant for ceps, can surely be
    % improved)
    if lpc>0
        [tfr_lpc, ~, ~, ~] = STFT_IFD_lpc_fast(x, fr/fs, hop, h2, Dh2, lpc);
        [ceps, iceps, ceptic] = ...
            cepstrum_convert(tfr_lpc, tfrtic, g, fs, Tc, num_c, HighFreq, LowFreq);
    else
        [ceps, iceps, ceptic] = ...
            cepstrum_convert(tfr, tfrtic, g, fs, Tc, num_c, HighFreq, LowFreq);
    end


    


    % get de-shape spectrogram
    tfr0 = tfr; 
    tfr0(tfr0-flo<0)=0;
    dstfr = tfr0.*iceps;
    dstfr(dstfr<0)=0;
    dstfr(1:round(LowFreq*fs/fr),:)=0;

    dstfr = dstfr(1:round(HighFreq*fs*num_s/fr),:);
    ifd = ifd(1:round(HighFreq*fs*num_s/fr),:);



    % run SST
    [tfr2, tfr3] = synchrosqueeze1win(dstfr, ifd, fr/fs, h2, num_s, fr, HighFreq, fs, ths, 'Smooth', Smo, 'Reject', Rej);
    [~, tfrsq] = synchrosqueeze1win(tfr0, ifd, fr/fs, h2, num_s, fr, HighFreq, fs, ths, 'Smooth', Smo, 'Reject', Rej);




    % if MT is needed
    if MT == 1
        if strcmp(feat,'STFT')
            dstfrsq = tfr2;
        elseif strcmp(feat,'SST11')
            dstfrsq = tfr3;
        end
    else
        if ii == 1
            if strcmp(feat,'STFT')
                dstfrsq = tfr2;
            elseif strcmp(feat,'SST11')
                dstfrsq = tfr3;
            end
        else
            if strcmp(feat,'STFT')
                dstfrsq = dstfrsq+tfr2;
            elseif strcmp(feat,'SST11')
                dstfrsq = dstfrsq + tfr3;
            end
        end
    end
end





% get the final result
dstfr = dstfr(1:round(HighFreq*fs/fr),:);
iceps = iceps(1:round(HighFreq*fs/fr),:);
tfr = tfr(1:round(HighFreq*fs/fr),:);


% pad zeros if the length is not correct (this could be improved)
start_idx = floor(Stime/fs/(hop/fs));
tfr = [zeros(size(dstfrsq,1), start_idx) tfr];
dstfr = [zeros(size(dstfrsq,1), start_idx) dstfr];
iceps = [zeros(size(dstfrsq,1), start_idx) iceps];
dstfrsq = [zeros(size(dstfrsq,1), start_idx) dstfrsq];
tfrtic = tfrtic(1:size(dstfrsq,1));


